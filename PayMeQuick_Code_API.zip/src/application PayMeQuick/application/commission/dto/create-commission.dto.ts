export class CreateCommissionDto {}
