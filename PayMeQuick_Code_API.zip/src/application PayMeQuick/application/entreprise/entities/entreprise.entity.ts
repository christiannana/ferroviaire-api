export class Entreprise {}
