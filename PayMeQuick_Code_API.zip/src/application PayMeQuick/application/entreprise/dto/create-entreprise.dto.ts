export class CreateEntrepriseDto {}
