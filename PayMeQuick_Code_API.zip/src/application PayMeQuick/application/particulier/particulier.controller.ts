import { Controller, Get, Post, Body, Patch, Param, Delete } from '@nestjs/common';
import { ParticulierService } from './particulierService';
import { CreateParticulierDto } from './dto/create-particulier.dto';
import { UpdateParticulierDto } from './dto/update-particulier.dto';

@Controller('particulier')
export class ParticulierController {
  constructor(private readonly particulierService: ParticulierService) {}

  @Post()
  create(@Body() createParticulierDto: CreateParticulierDto) {
    return this.particulierService.create(createParticulierDto);
  }

  @Post("login")
  onLogin(
     @Body('phone') phone: string,
     @Body('codeSecret') codeSecret: string,
     @Body('platformVersion') platformVersion: string,
     @Body('modelName') modelName: string,
     @Body('manufacturer') manufacturer: string,
    ) {
    return this.particulierService.onLogin(phone, codeSecret, platformVersion, modelName, manufacturer);
  }

  @Post("OTPcode_verify")
  onOTPverifyCode(
    @Body('userId') userId: string,
    @Body('phone') phone: string,
    @Body('otpcode') otpcode: string,
  ) {
    return this.particulierService.onOTP_code_verify(userId, phone, otpcode);
  }

  @Post("OTPcode_resend")
  onOTPresendCode(
     @Body('userId') userId: string,
     @Body('phone') phone: string,
  ) {
    return this.particulierService.onOTP_renvoyer(userId, phone);
  }

  

  @Get()
  findAll() {
    return this.particulierService.findAll();
  }

  @Get(':id')
  findOne(@Param('id') id: string) {
    return this.particulierService.findOne(id);
  }

  @Patch(':id')
  update(@Param('id') id: string, @Body() updateParticulierDto: UpdateParticulierDto) {
    return this.particulierService.update(id, updateParticulierDto);
  }

  @Post('deleteUser/:id')
  remove(
    @Body('userId') userId: string,
    @Body('codeSecret') codeSecret: string,
  ) {
    return this.particulierService.remove(userId, codeSecret );
  }
}
