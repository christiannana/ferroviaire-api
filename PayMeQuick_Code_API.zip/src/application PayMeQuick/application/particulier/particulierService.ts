import { BadRequestException, Injectable } from '@nestjs/common';
import { CreateParticulierDto } from './dto/create-particulier.dto';
import { UpdateParticulierDto } from './dto/update-particulier.dto';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import * as bcrypt from 'bcrypt';
import * as randomatic from 'randomatic';
import { SmsService } from 'src/application PayMeQuick/shared/services/sms/sms.service';

import * as crypto from 'crypto'; 
import axios from 'axios';

@Injectable()
export class ParticulierService {

  constructor(
    @InjectModel('pay_PARTICULIER') private PARTICULIER: Model<0>,
    @InjectModel('pay_HISTORIQUE_CONNEXION') private HISTORIQUE: Model<0>,
    @InjectModel('pay_COMPTE_FINANCIER') private COMPTE_FINANCIER: Model<0>,
    @InjectModel('pay_OTPCODE') private OTPCODE: Model<0>,
    private SMS: SmsService
  ) { }

  async create(createParticulierDto: CreateParticulierDto) {
    let dataParticulier = await this.PARTICULIER.findOne().where({ phone: createParticulierDto.phone, phoneVerify: true }).select({ codeSecret: 0 });
    console.log(dataParticulier);
    if (dataParticulier) throw new BadRequestException('Invalid input');
    let codeSecretRandom = randomatic('0', 5); // Generate a random 6-digit number
    const hashedPassword = await bcrypt.hash(codeSecretRandom, 10);
    createParticulierDto.codeSecret = hashedPassword;
    console.log(createParticulierDto);
    let particulier = await this.PARTICULIER.create(createParticulierDto);
    let compteFinancier = await this.COMPTE_FINANCIER.create({ userId: particulier._id, statusVerify: false, solde: 0 });
    const smsSend = this.SMS.onSMS_send("Bienvenue chez PayMeQuick, votre compte a été créé avec succès,\n\nLe Code Secrèt par defaut est: " + codeSecretRandom + "\nVous pouvez faire des modifications au niveau des paramètres de l'application.\nVisitez notre site web pour mieux nous connaitre\nhttps://www.paymequick.com/about \n\nMerci pour votre confiance.", createParticulierDto.phone);
    return { status: true, message: "Utilisateur créé avec succèc.", data: particulier };
  }


  async onLogin(phone, codeSecret, platformVersion, modelName, manufacturer) {
    let userData: any = await this.PARTICULIER.findOne().where({ phone: phone, });
    if (!userData) return { status: false, message: "Désolé, identifiants incorrect." };
    let compteFinancier = await this.COMPTE_FINANCIER.findOne().where({ userId: userData._id, });
    const match = await bcrypt.compare(codeSecret, userData.codeSecret);
    if (!match) return { status: false, message: "Désolé, identifiants incorrect." };
    let otpCheck = await this.HISTORIQUE.findOne().where({ userId: userData._id, });

    let OTP: boolean = false;
    if (otpCheck) {
      OTP = true;
      let OTPcode = randomatic('A0', 5);
      let otpCode = await this.OTPCODE.create({ userId: userData._id, phone: userData.phone, OTPcode: OTPcode });
      const smsSend = this.SMS.onSMS_send("Code de vérification de compte: " + otpCode, userData.phone);
    };

    let connexion = await this.HISTORIQUE.create({ userId: userData._id, phone_model: modelName, phone_manufacturer: manufacturer, phone_serie: platformVersion });
    if (userData.phoneVerify != true) {
      userData.phoneVerify = true;
      await userData.save();
    }

    let access_token = randomatic('A0', 56);
    return { status: true, message: "Connexion avec succèc.", userData: userData, compte_financier: compteFinancier, access_token: access_token, OTP: OTP };
  }

  async onOTP_code_verify(userId: string, phone: string, otpcode: string) {
    let otpCode = await this.OTPCODE.findOne().where({ userId: userId, phone: phone, OTPcode: otpcode });
    if(!otpCode) return { status: false, message: "Code OTP incorrect." };
    await this.OTPCODE.deleteMany().where({userId: userId, phone: phone,})
    return { status: true, message: "Code OTP correct." };
  }

  async onOTP_renvoyer(userId: string, phone: string,){
      let OTPcode = randomatic('A0', 5);
      let otpCode = await this.OTPCODE.create({ userId: userId, phone: phone, OTPcode: OTPcode });
      const smsSend = this.SMS.onSMS_send("Code de vérification de compte: " + otpCode, phone);
      return { status: true, message: "Code OTP renvoyer avec succès." };
  }








  async findAll() {
    let ob1 = {
      nana: "COOL"
    }
    let ob2 = {
      nana: "COOL"
    }
    let x = 5; let y = 6;
    let s = "PAY"
    if(ob1 == ob2){
      return {status: true}
    }
    return {status: false};
    try {
      let userData = await this.PARTICULIER.find().exec();
      return { status: true, message: "Liste des utilisateurs.", userData: userData, };
    } catch {
    }
  }

  async findOne(id: string) {

    var query = {serviceid: "20053"};
    let body = {}
   
    let input = {...query, ...body}

    let base_url: string = "https://s3pv2cm.smobilpay.com/v2/";  //  TEST
     
    let nonce = randomatic('A0', 20);
    // let signature = "A CALCULER";
    let signature_method = "HMAC-SHA1";
    let timestamp = Date.now().toString();
    let token = "EA311324-BDE8-F48E-9168-AAE10C951B41";

    // Authorization: s3pAuth,s3pAuth_nonce="634968823463411609",s3pAuth_signature="V5F+YLj2vQNTfZrmg3OYPFZJ4hw=",s3pAuth_signature_method="HMAC-SHA1",s3pAuth_timestamp="1361281946",s3pAuth_token="xvz1evFS4wEEPTGEFPHBog" 
    
    // var token = "";
    var secret = "B2A74CF1-2226-1D06-DAF2-03B87961A22A";
    // let url = "https://s3p.smobilpay.staging.maviance.info/v2/"+route 
    let url = "https://s3pv2cm.smobilpay.com/v2/" + "cashout"
    let auth_titleKey = "s3pAuth";
    let auth_tokenKey = "s3pAuth_token";
    let auth_nonceKey = "s3pAuth_nonce";
    let auth_signatureKey = "s3pAuth_signature";
    let auth_signatureMethodKey = "s3pAuth_signature_method";
    let auth_timestampKey = "s3pAuth_timestamp";
    let separator = ", ";
    // let signature_method = "HMAC-SHA1";
    // let timestamp = Date.now();
    // let nonce = Date.now();
    let s3pParams = {
        s3pAuth_nonce: nonce,
        s3pAuth_timestamp: timestamp,
        s3pAuth_signature_method: signature_method,
        s3pAuth_token: token
    }

    let dataChaine: string = "amount=1000&payItemId=SPAY-DEV-958-AES-100013333-10010"

    let requestDataChaine: string = "&s3pAuth_nonce="+nonce+"&s3pAuth_signature_method="+signature_method+"&s3pAuth_timestamp="+timestamp+"&s3pAuth_token="+token+"&serviceid=20053"


    
    let params = {...input, ...s3pParams};
    Object.keys(params).map(k => params[k] = typeof params[k] == 'string' ? params[k].trim() : params[k]);
    
    let sortedParams = Object.keys(params).sort().reduce((r, k) => (r[k] = params[k], r), {})
    let parameterString = Object.keys(sortedParams).map(key => key + '=' + sortedParams[key]).join('&');
    
    

    let baseString = "GET" + "&" + encodeURIComponent(url) + "&" + encodeURIComponent(parameterString);

    const hmac = crypto.createHmac('sha1', secret);
    hmac.update(baseString);
    const encodedSignature = hmac.digest('base64');
    // let signature =  crypto.createHmac(baseString, secret); //  crypto.AES.encrypt(baseString, secret)  // CryptoJS.HmacSHA1(baseString, secret);
  
    // let encodedSignature = CryptoJS.enc.Base64.stringify(signature);
    
    let auth_header =
                auth_titleKey + " " +
                auth_timestampKey + "=\"" + timestamp + "\"" + separator +
                auth_signatureKey + "=\"" + encodedSignature + "\"" + separator +
                auth_nonceKey + "=\"" + nonce + "\"" + separator +
                auth_signatureMethodKey + "=\"" + signature_method + "\"" + separator +
                auth_tokenKey + "=\"" + token + "\"";
    
    console.log('base string', baseString);

    const headers = {
      'Authorization': auth_header, // Replace with your actual token
      'Content-Type': 'application/json', // Optional: Specify content type if needed
    };
    
    const paramsUrl = {
      serviceid: "20053"
    };

   

    

    
    // let userData: any = await this.PARTICULIER.findById(id).exec();
    // let compteFinancier = await this.COMPTE_FINANCIER.findOne().where({ userId: userData._id });
    // return { status: true, message: "Opération réalisée avec succèc.", userData: userData, compte_financier: compteFinancier, };
    // return {}
  }

  async update(id: string, updateParticulierDto: UpdateParticulierDto) {
    let userData = await this.PARTICULIER.findByIdAndUpdate(id, updateParticulierDto, {});
    return { status: true, message: "Utilisateur mis a jour", userData: userData, };
  }

  async remove(id: string, codeSecret: string) {
    let userData: any = await this.PARTICULIER.findById(id).exec();
    const match = await bcrypt.compare(codeSecret, userData.codeSecret);
    if (!match) return { status: false, message: "Désolé, identifiants incorrect." };
    await this.PARTICULIER.findByIdAndDelete(id).exec();
    return { status: true, message: "Données Utilisateur supprimé avec succès.", userData: userData, };
  }


}
