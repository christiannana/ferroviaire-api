import { HttpModule, Module } from '@nestjs/common';
import { ParticulierService } from './particulierService';
import { ParticulierController } from './particulier.controller';
import { MongooseModule } from '@nestjs/mongoose';
import { pay_OTPCODE, pay_PARTICULIER } from './entities/particulier.entity';


import { pay_HISTORIQUE_CONNEXION } from '../historique-connexion/entities/historique-connexion.entity';
import { pay_COMPTE_FINANCIER } from '../compte-financier/entities/compte-financier.entity';
import { SmsService } from 'src/application PayMeQuick/shared/services/sms/sms.service';

@Module({
  imports: [
    MongooseModule.forFeature([
      { name: 'pay_PARTICULIER', schema: pay_PARTICULIER },
      { name: 'pay_HISTORIQUE_CONNEXION', schema: pay_HISTORIQUE_CONNEXION },
      { name: 'pay_COMPTE_FINANCIER', schema: pay_COMPTE_FINANCIER },
      { name: 'pay_OTPCODE', schema: pay_OTPCODE },
    ]),

    HttpModule,
  ],
  controllers: [ParticulierController],
  providers: [ParticulierService, SmsService],
})
export class ParticulierModule {}
