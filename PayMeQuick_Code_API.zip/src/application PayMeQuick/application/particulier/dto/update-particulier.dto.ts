import { PartialType } from '@nestjs/mapped-types';
import { CreateParticulierDto, ModifieParticulierDto } from './create-particulier.dto';

export class UpdateParticulierDto extends PartialType(ModifieParticulierDto) {}
