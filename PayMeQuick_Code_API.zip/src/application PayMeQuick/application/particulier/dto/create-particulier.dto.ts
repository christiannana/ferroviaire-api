import { ObjectId, Schema, Types } from "mongoose";


export class CreateParticulierDto {
    nom: String;
    prenom: String;
    phone: string;
    codeSecret: String;
    cniRecto: String;
    cniVerso: String;
    sexe: String;
    Type_user: String;
    KYC: [];
    KYCverify: Boolean = false;
    phoneVerify: Boolean = false;

}

export class ModifieParticulierDto {
    nom: String;
    prenom: String;
    cniRecto: String;
    cniVerso: String;
    sexe: String;
    Type_user: String;
    KYC: [];
    KYCverify: Boolean = false;
    phoneVerify: Boolean = false;

}

