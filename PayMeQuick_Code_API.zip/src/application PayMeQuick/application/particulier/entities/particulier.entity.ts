import mongoose from "mongoose";

export class Particulier { }

export const pay_PARTICULIER = new mongoose.Schema({
    nom: String,
    prenom: String,
    phone: { type: String, index: true },
    codeSecret: String,
    cniRecto: String,
    cniVerso: String,
    sexe: String,
    type_user: String,
    KYC: [],
    KYCverify: Boolean, 
    phoneVerify: Boolean, 
}, { timestamps: true });


export const pay_OTPCODE = new mongoose.Schema({
    userId: String,
    phone: String,
    OTPcode: String,
}, { timestamps: true });


