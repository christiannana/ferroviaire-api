import { Injectable } from '@nestjs/common';
import { CreateCompteFinancierDto } from './dto/create-compte-financier.dto';
import { UpdateCompteFinancierDto } from './dto/update-compte-financier.dto';

@Injectable()
export class CompteFinancierService {
  create(createCompteFinancierDto: CreateCompteFinancierDto) {
    return 'This action adds a new compteFinancier';
  }

  findAll() {
    return `This action returns all compteFinancier`;
  }

  findOne(id: number) {
    return `This action returns a #${id} compteFinancier`;
  }

  update(id: number, updateCompteFinancierDto: UpdateCompteFinancierDto) {
    return `This action updates a #${id} compteFinancier`;
  }

  remove(id: number) {
    return `This action removes a #${id} compteFinancier`;
  }
}
