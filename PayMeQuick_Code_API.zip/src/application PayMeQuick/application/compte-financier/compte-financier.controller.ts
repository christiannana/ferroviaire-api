import { Controller, Get, Post, Body, Patch, Param, Delete } from '@nestjs/common';
import { CompteFinancierService } from './compte-financier.service';
import { CreateCompteFinancierDto } from './dto/create-compte-financier.dto';
import { UpdateCompteFinancierDto } from './dto/update-compte-financier.dto';

@Controller('compte-financier')
export class CompteFinancierController {
  constructor(private readonly compteFinancierService: CompteFinancierService) {}

  @Post()
  create(@Body() createCompteFinancierDto: CreateCompteFinancierDto) {
    return this.compteFinancierService.create(createCompteFinancierDto);
  }

  @Get()
  findAll() {
    return this.compteFinancierService.findAll();
  }

  @Get(':id')
  findOne(@Param('id') id: string) {
    return this.compteFinancierService.findOne(+id);
  }

  @Patch(':id')
  update(@Param('id') id: string, @Body() updateCompteFinancierDto: UpdateCompteFinancierDto) {
    return this.compteFinancierService.update(+id, updateCompteFinancierDto);
  }

  @Delete(':id')
  remove(@Param('id') id: string) {
    return this.compteFinancierService.remove(+id);
  }
}
