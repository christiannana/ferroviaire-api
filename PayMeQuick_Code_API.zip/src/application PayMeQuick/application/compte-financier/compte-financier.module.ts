import { Module } from '@nestjs/common';
import { CompteFinancierService } from './compte-financier.service';
import { CompteFinancierController } from './compte-financier.controller';

@Module({
  controllers: [CompteFinancierController],
  providers: [CompteFinancierService],
})
export class CompteFinancierModule {}
