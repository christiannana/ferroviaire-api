export class CreateCompteFinancierDto {}
