export class HistoriqueTransaction {}
