export class CreateHistoriqueTransactionDto {}
