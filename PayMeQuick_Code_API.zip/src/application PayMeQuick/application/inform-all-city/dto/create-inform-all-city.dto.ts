export class CreateInformAllCityDto {}
