export class InformAllCity {}
