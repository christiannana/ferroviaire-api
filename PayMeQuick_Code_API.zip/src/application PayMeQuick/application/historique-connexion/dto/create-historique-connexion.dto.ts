
export class CreateHistoriqueConnexionDto {
    userId: String;
    phone_model: String;
    phone_manufacturer: String;
    phone_serie: String;
    phone_name: String;
}
