
import { HttpService, Injectable } from '@nestjs/common';
import axios from 'axios';

@Injectable()
export class SmsService {

    onHeader(){
       let header = {
        "Accept": "application/json",
        "Content-Type": "application/json"
       };
       return header;
    }

    constructor(private readonly httpService: HttpService) {}

    async onSMS_send(sms:string, phone:string) {
        let url = "https://smsvas.com/bulk/public/index.php/api/v1/sendsms";
        let datas =  {
            "user": "info@agis-as.com",
            "password": "AGIS12345",
            "senderid": "PAYMEQUICK",
            "sms": sms,
            "mobiles": phone
           }
           
        const response = await axios.post(url, datas,  {"headers": this.onHeader() } );
        return response.data;
    }

      
}
