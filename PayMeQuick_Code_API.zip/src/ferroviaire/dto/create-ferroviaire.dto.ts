export class CreateFerroviaireDto {

    
}
