// import { PartialType } from '@nestjs/mapped-types';
import { CreateFerroviaireDto } from './create-ferroviaire.dto';

// export class UpdateFerroviaireDto extends PartialType(CreateFerroviaireDto) {}

export class UpdateFerroviaireDto {}

