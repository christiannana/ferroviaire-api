


export class CreatePersonnelDto {
    nom: String;
    prenom: String;
    dateNaissance: Date;
    adresse: String;
    emailPersonnel: String;
    telephonePersonnel: String;
    fonction: String;
    typeContrat: String;
    dateRecrutement: Date;
    emailProffessionnel: String;
    telephoneProffessionnel: String;
    codeAcces: String;
    droitAcces: String;
    photo: String;
    
}

