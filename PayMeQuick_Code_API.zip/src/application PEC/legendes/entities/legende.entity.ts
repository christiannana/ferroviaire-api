export class Legende {}
