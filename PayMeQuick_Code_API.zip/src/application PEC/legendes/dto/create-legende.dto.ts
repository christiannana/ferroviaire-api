export class CreateLegendeDto {

    titre: String;
    description: String;
    legende: String;
    auteur: String;
    date: Number;

}
