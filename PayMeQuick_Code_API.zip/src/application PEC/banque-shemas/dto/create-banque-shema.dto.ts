export class CreateBanqueShemaDto {}
