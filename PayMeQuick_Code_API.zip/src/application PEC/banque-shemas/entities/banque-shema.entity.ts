export class BanqueShema {}
