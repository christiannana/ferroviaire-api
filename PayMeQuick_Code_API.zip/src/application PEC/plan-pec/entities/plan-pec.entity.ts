export class PlanPec {}
